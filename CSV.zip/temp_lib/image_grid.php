<div class="row-fluid">
                        <div class="span6">
							<div class="heading clearfix">
								<h3 class="pull-left">Latest Orders</h3>
								<span class="pull-right label label-important">5 Orders</span>
							</div>
							<?php include 'temp_lib/datatable.php'; ?>
                        </div>
                        <div class="span6">
							<div class="heading clearfix">
								<h3 class="pull-left">Latest Images <small>(gallery grid)</small></h3>
								<span class="pull-right label label-success">10</span>
							</div>
							<div id="small_grid" class="wmk_grid">
								<ul>
									<li class="thumbnail">
										<a title="Image_4 title long title long title long" href="gallery/Image04.jpg">
											<img alt="" src="gallery/Image04_tn.jpg">
										</a>
										<p>
											<span>302KB<br>15/05/2012</span>
										</p>
									</li>
									<li class="thumbnail">
										<a title="Image_5 title long title long title long" href="gallery/Image05.jpg">
											<img alt="" src="gallery/Image05_tn.jpg">
										</a>
										<p>
											<span>336KB<br>24/05/2012</span>
										</p>
									</li>
									<li class="thumbnail">
										<a title="Image_6 title long title long title long" href="gallery/Image06.jpg">
											<img alt="" src="gallery/Image06_tn.jpg">
										</a>
										<p>
											<span>258KB<br>27/06/2012</span>
										</p>
									</li>
									<li class="thumbnail">
										<a title="Image_7 title long title long title long" href="gallery/Image07.jpg">
											<img alt="" src="gallery/Image07_tn.jpg">
										</a>
										<p>
											<span>338KB<br>22/06/2012</span>
										</p>
									</li>
									<li class="thumbnail">
										<a title="Image_8 title long title long title long" href="gallery/Image08.jpg">
											<img alt="" src="gallery/Image08_tn.jpg">
										</a>
										<p>
											<span>381KB<br>25/06/2012</span>
										</p>
									</li>
									<li class="thumbnail">
										<a title="Image_9 title long title long title long" href="gallery/Image09.jpg">
											<img alt="" src="gallery/Image09_tn.jpg">
										</a>
										<p>
											<span>176KB<br>11/06/2012</span>
										</p>
									</li>
									<li class="thumbnail">
										<a title="Image_10 title long title long title long" href="gallery/Image10.jpg">
											<img alt="" src="gallery/Image10_tn.jpg">
										</a>
										<p>
											<span>380KB<br>20/06/2012</span>
										</p>
									</li>
									<li class="thumbnail">
										<a title="Image_11 title long title long title long" href="gallery/Image11.jpg">
											<img alt="" src="gallery/Image11_tn.jpg">
										</a>
										<p>
											<span>340KB<br>17/06/2012</span>
										</p>
									</li>
									<li class="thumbnail">
										<a title="Image_12 title long title long title long" href="gallery/Image12.jpg">
											<img alt="" src="gallery/Image12_tn.jpg">
										</a>
										<p>
											<span>191KB<br>27/05/2012</span>
										</p>
									</li>
									<li class="thumbnail">
										<a title="Image_13 title long title long title long" href="gallery/Image13.jpg">
											<img alt="" src="gallery/Image13_tn.jpg">
										</a>
										<p>
											<span>314KB<br>24/05/2012</span>
										</p>
									</li>
									<li class="thumbnail">
										<a title="Image_14 title long title long title long" href="gallery/Image14.jpg">
											<img alt="" src="gallery/Image14_tn.jpg">
										</a>
										<p>
											<span>141KB<br>17/06/2012</span>
										</p>
									</li>
									<li class="thumbnail">
										<a title="Image_15 title long title long title long" href="gallery/Image15.jpg">
											<img alt="" src="gallery/Image15_tn.jpg">
										</a>
										<p>
											<span>183KB<br>13/05/2012</span>
										</p>
									</li>
									 
								</ul>
							</div>
                        </div>
                    </div>