<?php
//error_reporting(E_ERROR | E_PARSE | E_CORE_ERROR);
$_SESSION['id']=session_id();
$_SESSION['userid']=$userid;
?>