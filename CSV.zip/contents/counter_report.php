<div class="row-fluid">
						<div class="span12 tac">
							<ul class="ov_boxes">
								<li>
									<div class="p_bar_up p_canvas">2,4,9,7,12,8,16</div>
									<div class="ov_text">
										<strong>$3 458,00</strong>
										Weekly Sale
									</div>
								</li>
								<li>
									<div class="p_bar_down p_canvas">20,15,18,14,10,13,9,7</div>
									<div class="ov_text">
										<strong>$43 567,43</strong>
										Monthly Sale
									</div>
								</li>
								<li>
									<div class="p_line_up p_canvas">3,5,9,7,12,8,16</div>
									<div class="ov_text">
										<strong>2304</strong>
										Unique visitors (last 24h)
									</div>
								</li>
								<li>
									<div class="p_line_down p_canvas">20,16,14,18,15,14,14,13,12,10,10,8</div>
									<div class="ov_text">
										<strong>30240</strong>
										Unique visitors (last week)
									</div>
								</li>
							</ul>
						</div>
					</div>